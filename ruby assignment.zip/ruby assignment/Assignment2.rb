class A
def encryption(str,n)
atoz=('A'..'Z').to_a 
ctext=""
ctmp=str.tr('A-Z',(atoz[n..25]<< atoz[0...n]).flatten.join).tr('0-9',('0'..'9').to_a.reverse.join)
ctmp.each_char.with_index {|c,i|
if i.even?
ctext << c.upcase
else
ctext << c.downcase
end
}
ctext.reverse
end
a1=A.new
p a1.encryption("hello world 34 is here",1)
end
