a=10
b=30
if a>b
	p "a is greater"
elsif 
	p "b is greater"
else
	p "a and b are equal"
end
