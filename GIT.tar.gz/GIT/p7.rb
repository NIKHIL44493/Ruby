class Being
	@@is=true
	def initialize nm
		@name=nm
	end
	def to_s
		"this is #{@name}"
	end
	def does_exist?
		@@is
	end
end
b1 = Being.new "jutu"
b2 = Being.new "Maze"
b3 = Being.new "ParkPro"
p b1,b2,b3
p b1.does_exist?
p b2.does_exist?
p b3.does_exist?
p b1.to_s
p b2.to_s
p b3.to_s
