VALUE = {"M"=> 1000,"D"=> 500 , "C"=> 100, "L"=> 50,"X"=> 10,"V"=> 5, "I"=>1}

class A
def roman_num n
  roman = ""
  p "numbers is #{n}"
  VALUE.each do |pair|
    letter = pair[0]
    value = pair[1]
    roman += letter*(n / value)
     n = n % value
  end
  return roman
end
end
a1=A.new

p"Roman Encoding = #{a1.roman_num 1996}"
