a=20
case a
	when 10 then p "value of a is 10"
        when 35 then p "value of a is 20"
	when 30 then p "value of a is 30"
	else
		p "not present"
end
a="king"
case a
	when 10 then p "value of a is 10"
        when "king" then p "value of a is a=#{a}"
	when 30 then p "value of a is 30"
	else
		p "not present"
end
