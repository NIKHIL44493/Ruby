def gcd(a,b)
b==0 ? a: gcd(b,a.modulo(b))
end

def nooflap(x,y)
 lcm = x * y / gcd(x,y)
 [lcm /x,lcm /y]
 
end
p nooflap(10,6)

