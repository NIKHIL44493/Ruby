a=20
b=12
c = a>b ? a : b
p "c value is c=#{c}"
