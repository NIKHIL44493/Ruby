def method1
x=5
p x
end
method1
#p x it is an error as it not confined to global level;
