print "hello Nikhil Singh"
print "welcome 34 world.com"
